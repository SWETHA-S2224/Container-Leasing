import { Component, OnInit } from '@angular/core';
import { Router } from 'express';
import { ContainerService } from '../container.service';
import { IContainer } from '../icontainer';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrl: './list.component.css'
})
export class ListComponent implements OnInit {
  houses:IContainer[]=[];

  constructor(private conService:ContainerService){}
  ngOnInit(): void {
    this.conService.getAllHouses()
    .subscribe({
      next:(houses)=>
      {
       
        this.houses=houses;
        console.log(houses);
      
      },
      error:(response)=>
      {
        console.log(response);
      }

      
    })
  }
 
}
