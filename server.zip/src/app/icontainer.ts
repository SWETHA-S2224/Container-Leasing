export interface IContainer {
    container_No:string,
    lessee:string,
    lease_Start_Date:Date,
    lease_End_Date:Date,
    customer_Name:string,
    origin:string,
    destination:string,
    container_Type:string,
    lease_Duration:number,
    lease_Amount:number,
    shipping_Company:string
}