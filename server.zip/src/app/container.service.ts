import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IContainer } from './icontainer';

@Injectable({
  providedIn: 'root'
})
export class ContainerService {

  baseApiUrl:string="https://localhost:7139";
  baseUrl:string="https://localhost:7139/api/ContainerDetails";

  constructor(private http:HttpClient) { }
  getAllHouses():Observable<IContainer[]>
  {
     return this.http.get<IContainer[]>(this.baseApiUrl+'/api/ContainerDetails');
  }
}
